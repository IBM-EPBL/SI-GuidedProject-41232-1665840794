import ibm_db
conn = ibm_db.connect("database","username","password")
